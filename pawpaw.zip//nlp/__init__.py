from .nlp import Number, Sentence, SimpleNlp
