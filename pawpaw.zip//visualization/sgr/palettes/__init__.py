from .palettes import PAWPAW
del palettes